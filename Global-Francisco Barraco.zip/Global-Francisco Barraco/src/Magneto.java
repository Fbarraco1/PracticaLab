//Importo las clases
import static Funciones.Funciones.*;
import java.util.Scanner;


public class Magneto {

    public static void main(String[] args) {

        System.out.println("Bienvenido Magneto, vamos a comprobar si el ADN es mutante");
        Scanner scanner = new Scanner(System.in);

        //Uso un bucle while para que se repita las veces que uno desee
        while (true) {
            //Creo una matriz vacía con un tamaño de 6x6
            String[][] dna = new String[6][6];

            fill(dna); //Llamo a la función para llenar la matriz

            show(dna); //Muestro la matriz

            System.out.println(isMutant(dna)); //Imprimo la funcion para ver si el ADN es mutante o no

            System.out.print("Escriba 'S' para comprobar otra secuencia de ADN o cualquier otra tecla para cancelar: ");
            String s = scanner.nextLine().toUpperCase();

            if (s.equals("S")) {
                continue;
            } else {
                break;
            }
        }
    }
}
