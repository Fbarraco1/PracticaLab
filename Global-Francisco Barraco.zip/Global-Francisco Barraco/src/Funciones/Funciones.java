package Funciones;
import java.util.Arrays;
import java.util.Scanner;

public class Funciones {
    //Funcion encargada de llenar la matriz
    public static void fill(String[][] dna) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Completa la secuencia de ADN");
        int space = 6; // Defino una variable con el espacio de la matriz
        int i = 0; // Uso un bucle while para que solo se ingresen 6 filas en la matriz
        while (i < 6) {
            System.out.print("Ingrese la secuencia de 6 letras (A, T, C o G): ");
            String sequence = scanner.nextLine().toUpperCase();
            if (sequence.length() != space || !sequence.matches("[ATCG]{6}")) {
                // Creo una condicion en donde si los valores ingresados no cumplen con las letras y cantidades pedidas, muestre un mensaje de error.
                System.out.println("Ingrese SOLO 6 letras que sean A, T, C o G"); // Mensaje de error
            } else {
                // Si los valores son correctos se almacenan en la matriz, en formato de array
                dna[i] = sequence.split("");
                i++; // Aumento el valor de i hasta llegar a 6
            }
        }
    }


    //Funcion que imprime la matriz fila por fila
    public static void show(String[][] dna) {

        for (String[] a : dna) {
            System.out.println(Arrays.toString(a));
        }
    }


    //Esta funcion se encarga de comprobar y devolver True o False, según la secuencia de ADN
    public static boolean isMutant(String[][] dna) {

        if ((horizontal(dna) + vertical(dna) + diagonal1(dna) + diagonal2(dna)) > 1) {

            // Sumamos las coincidencias encontradas
            return true; //Si hay más de 1 coincidencia de 4 letras, es mutante

        } else {

            return false; // Si no, es falso
        }
    }


    //Esta funcion se encarga de recorrer la matriz de forma horizontal para encontrar las coincidencias
    public static int horizontal(String[][] dna) {

        int n = dna.length;
        int count = 0; //Guardamos la cantidad de concidencias encontradas

        for(int i = 0; i < n; i++) {

            boolean found = false;

            for(int j = 0; j < n - 3; j++) {

                //Uso un bucle for para recorrer la matriz y encontar un patron de 4 coincidencias
                if(dna[i][j].equals(dna[i][j+1]) &&
                        dna[i][j+1].equals(dna[i][j+2]) &&
                        dna[i][j+2].equals(dna[i][j+3])) {

                    if(!found) {

                        //Con esta condicion me aseguro que solo verifique una coincidencia por la misma fila
                        count++;
                        found = true;
                    }
                }
            }
        }

        return count;
    }


    //Esta funcion se encarga de recorrer la matriz de forma vertical para encontrar las coincidencias
    public static int vertical(String[][] dna) {

        int n = dna.length;
        int count = 0; //Guardamos la cantidad de concidencias encontradas

        for(int i = 0; i < n - 3; i++) {

            boolean found = false;

            for(int j = 0; j < n; j++) {

                //Uso un bucle for para recorrer la matriz y encontar un patron de 4 coincidencias
                if(dna[i][j].equals(dna[i+1][j]) &&
                        dna[i+1][j].equals(dna[i+2][j]) &&
                        dna[i+2][j].equals(dna[i+3][j])) {

                    if(!found) {

                        //Con esta condicion me aseguro que solo verifique una coincidencia por la misma columna
                        count++;
                        found = true;
                    }
                }
            }
        }

        return count;
    }


    //Esta funcion se encarga de recorrer la matriz de forma diagonal, de derecha a izquierda para encontrar las coincidencias
    public static int diagonal1(String[][] dna) {

        int n = dna.length;
        int count = 0; //Guardamos la cantidad de concidencias encontradas

        for(int i = 0; i < n - 3; i++) {

            boolean found = false;

            for(int j = 0; j < n - 3; j++) {

                //Uso un bucle for para recorrer la matriz y encontar un patron de 4 coincidencias
                if(dna[i][j].equals(dna[i+1][j+1]) &&
                        dna[i+1][j+1].equals(dna[i+2][j+2]) &&
                        dna[i+2][j+2].equals(dna[i+3][j+3])) {

                    if(!found) {

                        //Con esta condicion me aseguro que solo verifique una coincidencia por la misma diagonal
                        count++;
                        found = true;
                    }
                }
            }
        }

        return count;
    }


    //Esta funcion se encarga de recorrer la matriz de forma diagonal, de izquierda a derecha para encontrar las coincidencias
    public static int diagonal2(String[][] dna) {

        int n = dna.length;
        int count = 0; //Guardamos la cantidad de concidencias encontradas

        for(int i = 3; i < n; i++) {

            boolean found = false;

            for(int j = 0; j < n - 3; j++) {

                //Uso un bucle for para recorrer la matriz y encontar un patron de 4 coincidencias
                if(dna[i][j].equals(dna[i-1][j+1]) &&
                        dna[i-1][j+1].equals(dna[i-2][j+2]) &&
                        dna[i-2][j+2].equals(dna[i-3][j+3])) {

                    if(!found) {

                        //Con esta condicion me aseguro que solo verifique una coincidencia por la misma diagonal
                        count++;
                        found = true;
                    }
                }
            }
        }

        return count;
    }
}
